import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
// Native components
import { GoogleMaps, GoogleMap, GoogleMapsEvent, LatLng, MarkerCluster} from '@ionic-native/google-maps';
import { NativeGeocoder, NativeGeocoderReverseResult} from '@ionic-native/native-geocoder';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private map:GoogleMap;
  private location:LatLng;
  private locations:Array<any> =[];
  private markerCluster:MarkerCluster;
  private 
  
  constructor(public navCtrl: NavController, public platform: Platform, private nativeGeocoder: NativeGeocoder) {
    this.location = new LatLng(42.346903, -71.135101);
    this.locations.push({position:{lat:42.346983,lng:-71.135101}});
    this.locations.push({position:{lat:42.342525,lng:-71.135943}});
    this.locations.push({position:{lat:42.345792,lng:-71.138167}});
    this.locations.push({position:{lat:42.320684,lng:-71.182951}});
    this.locations.push({position:{lat:42.36,lng:-71.1}});
    platform.ready().then(() => {
      this.loadMap();
		});
  }
  loadMap() {
    // create a new map by passing HTMLElement
    let element: HTMLElement = document.getElementById('map');
    this.map = GoogleMaps.create(element);
    // listen to MAP_READY event
    // You must wait for this event to fire before adding something to the map or modifying it in anyway
    this.map.one(GoogleMapsEvent.MAP_READY).then(
      () => {
        console.log('maps  is reay');
        // Now you can add elements to the map like the marker
            let options = {
              target: this.location,
              zoom: 8
            };
            this.map.moveCamera(options);
            setTimeout(() => {this.addCluster()}, 2000);
      }
    );
    this.addEventListners();
}

  addCluster() {
   
    this.map.addMarkerCluster({
      markers: this.locations,
      icons: [
        {min: 2, max: 100, url: "./assets/icon/blue-dot.png", anchor: {x: 16, y: 16}}
      ]
    })
    .then((markerCluster) => {
      this.markerCluster= markerCluster;
      markerCluster.on(GoogleMapsEvent.MARKER_CLICK).subscribe((cluster: any) => {
        console.log('cluster was clicked.');
      });
      
    });
  }

  addEventListners(){
    this.map.on(GoogleMapsEvent.MAP_LONG_CLICK)
    .subscribe((latLng) => {
      this.addMarker(latLng[0]);
      });
  }
  getAddress(position:LatLng){
  let address="";
  this.nativeGeocoder.reverseGeocode(52.5072095, 13.1452818)
  .then((result: NativeGeocoderReverseResult) => address=result.administrativeArea)
  .catch((error: any) => console.log(error));
  return address;
  }
  addMarker(position:LatLng) {
    this.map.addMarker({
      //title: this.getAddress(position),
      animation: 'DROP',
      position: {
        lat: position.lat,
        lng: position.lng
      }
    })
    .then(marker => {
      marker.on(GoogleMapsEvent.MARKER_CLICK).subscribe(() => {
      });
      this.markerCluster.addMarker(marker);
    });
  }
}